import json
import math
import statistics
import sys
from collections import Counter, defaultdict
from pathlib import Path
from harness.artifacts import digest, read, suite_hash, write
from harness.validation import check
from harness.workload import build

run = Path(sys.argv[1]).resolve()
reference = run.parent / '20261012T113832092061Z-c0ad33'
m = read(run/'manifest.json')
reference_manifest = run/'reference_manifest.json'
old = read(reference_manifest if reference_manifest.exists() else reference/'manifest.json')
assert m['status'] == 'completed', m['status']
assert len(m['cases']) == 48 and len(m['jobs']) == 192
assert len({(j['case_id'], j['solution']) for j in m['jobs']}) == 192
assert suite_hash(run/'suite_snapshot') == m['suite_sha256']
assert m['config']['solutions'] == ['sid_gr_inference','vllm_gr','tensorrt_llm','flash_rec']
assert m['config']['baseline'] == 'sid_gr_inference'
assert not m['config'].get('smoke')
for name, cfg in m['config']['scenario_configs'].items():
    prev = old['config']['scenario_configs'][name]
    for key in ['inputs', 'generation', 'measurement']:
        assert cfg[key] == prev[key], (name, key)
    for key in ['id', 'revision', 'dtype', 'kv_cache_dtype', 'quantization']:
        assert cfg['model'][key] == prev['model'][key], (name,key)
cases = {r['case']['id']:r for r in m['cases']}
prior_cases = {r['case']['id']:r for r in old['cases']}
workloads = {}
for cid, row in cases.items():
    workload = read(run/'workloads'/f"{cid.replace('/', '_')}.json")
    prior = prior_cases[cid]
    assert digest(workload) == digest(build(prior['case'], prior['model']['config'])), cid
    assert row['model']['sha256'] == prior['model']['sha256'], cid
    workloads[cid] = workload
summary = {(r['case'],r['solution']):r for r in read(run/'summary.json')}
assert len(summary) == 192
counts = defaultdict(Counter)
samples = 0
for j in m['jobs']:
    key = j['case_id'],j['solution']
    result = read(run/j['directory']/'result.json')
    req = read(run/j['directory']/'request.json')
    assert req['suite_sha256'] == m['suite_sha256']
    assert req['measurement'] == {'warmup_runs':5,'repeats':30}
    assert result['status'] == j['status'] == summary[key]['status']
    assert result['workload_sha256'] == digest(workloads[key[0]])
    counts[j['solution']][j['status']] += 1
    if result['status'] != 'success':
        assert result.get('reason'), key
        continue
    assert not result['profiled']
    assert len(result['samples_ms']) == len(result['outputs']) == 30
    assert all(math.isfinite(t) and t > 0 for t in result['samples_ms'])
    assert math.isclose(statistics.median(result['samples_ms']), summary[key]['median_ms'])
    row = cases[key[0]]
    for output in result['outputs']:
        check(output, workloads[key[0]], row['case'], row['model']['config']['vocab_size'])
    samples += len(result['samples_ms'])
result = {
    'status':'passed', 'reference_run':str(reference),
    'checks':['48 identical token workloads and checkpoint file hashes',
              'same precision, generation rules, five warmups and 30 timed repeats',
              '192 unique case/candidate rows with matching saved status',
              'one frozen suite identity for every worker and the saved source snapshot',
              'all successful raw outputs structurally valid; report medians match samples'],
    'jobs_by_solution':dict(counts),'timed_samples':samples,
    'workload_sha256': {cid:digest(workload) for cid,workload in workloads.items()},
    'suite_sha256':m['suite_sha256'],
    'previous_hardware':old['hardware'],'current_hardware':m['hardware'],
    'baseline':'sid_gr_inference',
}
write(run/'protocol_audit.json', result)
print(json.dumps(result, indent=2))
