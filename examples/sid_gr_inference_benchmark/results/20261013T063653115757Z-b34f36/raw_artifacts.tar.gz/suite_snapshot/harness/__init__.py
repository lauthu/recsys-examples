"""Benchmark harness."""
