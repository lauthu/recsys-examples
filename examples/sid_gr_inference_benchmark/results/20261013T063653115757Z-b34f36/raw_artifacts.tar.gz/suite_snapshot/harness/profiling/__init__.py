"""Benchmark profiling."""
